<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    //Register Methods Create
    public function register(Request $request)
    {
       $validator = Validator::make($request->all(),[
            'name' =>'required|string|min:4|max:80',
            'email' =>'required|email|string|max:80|unique:users',
            'password' =>'required|string|min:6|confirmed',

        ]);

        if($validator->fails())
        {
            return response()->json($validator->errors(),400);
        }

         $user = User::create([
            'name' =>$request->name,
            'email' =>$request->email,
            'password' =>Hash::make($request->password),
         ]);

         return response()->json([
            'message' => 'User register Sucessfully',
            'user' => $user
         ]);
    }


    // Login Method
    public function login(Request $request){

        $validator = Validator::make($request->all(),[
            'email' =>'required|email|string',
            'password' =>'required|string|min:6',

        ]);

        if($validator->fails())
        {
            return response()->json($validator->errors(),400);
        }

        if(!$token = auth()->attempt($validator->validate())){
                return response()->json(['error'=>'UnAuthorized']);
        }
         return $this->respondWithToken($token);
    }
    protected function respondWithToken($token)
    {
        return response()->json([
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => auth()->factory()->getTTL() * 60
        ]);
    }

    public function profile(){
        return response()->json(auth()->user());
    }

    public function refresh(){
        return $this->respondWithToken(auth()->refresh());

    }

    public function logout(){
        auth()->logout();
        return response()->json(['message'=>'User Successfully logout']);
    }
}
